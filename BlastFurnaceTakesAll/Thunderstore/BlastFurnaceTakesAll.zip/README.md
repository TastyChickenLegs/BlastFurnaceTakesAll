# Blast Furnace Takes All

### About the Mod:
<b>from Tueman Blast Furnace All Ore Mod </b>

### Rebuilt for Mistlands

This mod is a combination of my own code and Tueman's Blast Furnace All Ore Mod  

Credit goes to Tueman for the idea and original mod.

- <b>Now has Mistlands CopperScrap</b>
___
### Blast Furnace Smelts All Ore
___
Blast Furnace now smelts all ore to include Copper Scrap in Mistlands.

___
### Installation: (manual)  
Extract DLL from zip file into "<GameDirectory>\Bepinex\plugins"  
Start the game.

### Version Information

1.0.9


Updated for newest version 0.219.10
Added Iron Ore to the list of items to be made in Blast Furnace
-- Thanks EiraValkyrie for reporting the problem


1.0.8

- romoved for build errors

1.0.7

- udpdated to take Bronze Scrap - Thanks Kherae for the help.  


1.0.6

- updated for Ashlands

1.0.5

- updated for Valheim 0.271.22


1.0.4

- updated to Hildir's Request


1.0.3

- update to newest Valheim Patch 0.214.300


1.0.2

- updated to newest valheim patch

1.0.0

- initial release - Fixed for Mistlands